
const productDetail = [{
    id: 2,
    title: "Remera Ikki",
    price: 2200,
    stock: 14,
    image: 'ikki.jpg'
    
}]

export default productDetail;
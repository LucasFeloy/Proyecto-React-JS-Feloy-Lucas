const Products=[{
    id:1,
    title: "Remera Charizard",
    price: 2125,
    stock: 12,
    image: "charizard.jfif",
    category:"Anime"
},
{
    id:2,
    title: "Remera Ikki",
    price: 2200,
    stock: 14,
    image: 'ikki.jpg',
    category:'Anime'
},
{
    id:3,
    title: "Remera Eva",
    price: 2050,
    stock: 10,
    image:"remeraEva.webp",
    category:'Anime'
},
{
    id:4,
    title: "Remera Goku",
    price: 2235,
    stock: 16,
    image:"gokuUi.jpg",
    category:'Anime'
},
{
    id:5,
    title: "Remera Friends",
    price: 2100,
    stock: 20,
    image:"friends.jpeg",
    category:'Series'
},
{
    id:6,
    title: "Remera Homero",
    price: 2235,
    stock: 16,
    image:"homeroPastelito.jpg",
    category:'Simpsons'
},
{
    id:7,
    title: "Remera Star Wars",
    price: 2235,
    stock: 11,
    image:"logoStarwars.jpg",
    category:'Star Wars'
},

]

export default Products;
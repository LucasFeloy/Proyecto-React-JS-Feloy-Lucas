import ItemDetailContainer from "../components/ItemDetailContainer/ItemDetailContainer";
import ItemList from "../components/ItemList/ItemList";

const DetailProduct=()=>{
    return(
        
        <ItemDetailContainer/>
       
    )
}

export default DetailProduct;
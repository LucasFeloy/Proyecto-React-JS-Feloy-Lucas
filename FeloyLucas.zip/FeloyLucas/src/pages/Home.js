import ItemListContainer from "../components/ItemListContainer/ItemListContainer";


const Home=()=>{
    return(
        <ItemListContainer/>
    )
}

export default Home;